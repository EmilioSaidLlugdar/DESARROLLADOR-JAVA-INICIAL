import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {

        Path resultados = Paths.get(args[0]);

        Path pronosticos = Paths.get(args[1]);

        int rondaNumero = 1;
        try {
            // Genero la ronda
            Ronda ronda = new Ronda();
            // Genero un array de partidos, exagerando su dimensión
            Partido[] partidos = new Partido[80];

            for (int i = 1; i < Files.readAllLines(resultados).size(); i++) {
                String line = Files.readAllLines(resultados).get(i);
                Partido partidito = new Partido();
                String[] dataString = line.split(",");
                Equipo equipo1 = new Equipo(dataString[0], "Local");
                Equipo equipo2 = new Equipo(dataString[3], "Visitante");
                partidito.setEquipo1(equipo1);
                partidito.setEquipo2(equipo2);
                partidito.setGolesEquipo1(Integer.parseInt(dataString[1]));
                partidito.setGolesEquipo2(Integer.parseInt(dataString[2]));
                partidos[i] = partidito;
                System.out.println(line);
            }


            for (int i = 1; i < Files.readAllLines(pronosticos).size(); i++) {
                String line = Files.readAllLines(pronosticos).get(i);
                Pronostico pronostico = new Pronostico();
                System.out.println(line);
            }
//            Files.readAllLines(pronosticos).get(0);
//            System.out.println("PRONOSTICO");
//            for (String line : Files.readAllLines(pronosticos).get(1)) {
//
//            }

//            System.out.println("==============================");
//
//            System.out.println("RESULTADOS");
//            for (String line : Files.readAllLines(resultados)) {
//                System.out.println(line);
//            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
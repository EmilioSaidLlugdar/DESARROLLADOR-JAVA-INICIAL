public enum ResultadoEnum {
    GANADOR,PERDEDOR,EMPATE
}

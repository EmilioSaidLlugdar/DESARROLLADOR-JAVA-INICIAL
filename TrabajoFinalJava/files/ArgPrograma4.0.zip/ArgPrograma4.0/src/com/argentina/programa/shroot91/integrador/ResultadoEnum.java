package com.argentina.programa.shroot91.integrador;

public enum ResultadoEnum {
    GANADOR,PERDEDOR,EMPATE
}

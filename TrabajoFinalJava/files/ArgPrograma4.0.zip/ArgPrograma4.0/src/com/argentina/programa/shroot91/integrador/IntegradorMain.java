package com.argentina.programa.shroot91.integrador;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class IntegradorMain {

    /*
    *
    * A partir del esquema original propuesto, desarrollar un programa que lea un archivo de
      partidos y otro de resultados, el primero correspondiente a una ronda y el otro que contenga
      los pronósticos de una persona1. Cada ronda debe tener una cantidad fija de partidos, por
      ejemplo 2.
    *
    *
    * */
    public void primeraEntrega(String[] args) {
        Path resultados = Paths.get(args[0]);
        Path pronosticos = Paths.get(args[1]);
        int puntos = 0;
        try {
            // Genero la ronda
            Ronda ronda = new Ronda();
            ronda.setNro("1");

            //Maximo 2 partidos
            Partido[] partidos = new Partido[2];


            //Comienzo a leer el archivo
            for (int i = 1; i < Files.readAllLines(resultados).size(); i++) {
                // Leo desde la segunda linea [1]
                String line = Files.readAllLines(resultados).get(i);

                System.out.println("===============================");
                System.out.println(line);

                Partido partidito = new Partido();//Se crea el objeto
                partidito.setIdPartido(i);

                String[] dataString = line.split(",");// Split para obtener datos, se en que posiciones está cada dato

                Equipo equipo1 = new Equipo(dataString[0], "Local");
                Equipo equipo2 = new Equipo(dataString[3], "Visitante");

                partidito.setEquipo1(equipo1);
                partidito.setEquipo2(equipo2);

                partidito.setGolesEquipo1(Integer.parseInt(dataString[1]));
                partidito.setGolesEquipo2(Integer.parseInt(dataString[2]));
                System.out.println("===============================");
                System.out.println("Equipo 1 -> " + partidito.resultado(partidito.getEquipo1()));
                System.out.println("Equipo 2 -> " + partidito.resultado(partidito.getEquipo2()));

                //añado el partido al conjunto de partidos
                partidos[i - 1] = partidito;

            }

            ronda.setPartidos(partidos);
            Pronostico[] pronostics = new Pronostico[2];

            for (int i = 1; i < Files.readAllLines(pronosticos).size(); i++) {
                String line = Files.readAllLines(pronosticos).get(i);
                String[] dataString = line.split(",");
                Pronostico pronostico = new Pronostico();
                pronostico.setPartido(partidos[i - 1]);

                if (dataString[1].toLowerCase().contains("x")) {
                    pronostico.setEquipo(partidos[i - 1].getEquipo1());
                    pronostico.setResultadoEnum((ResultadoEnum.GANADOR));

                } else if (dataString[3].toLowerCase().contains("x")) {
                    pronostico.setEquipo(partidos[i - 1].getEquipo2());
                    pronostico.setResultadoEnum((ResultadoEnum.GANADOR));

                } else {
                    pronostico.setResultadoEnum((ResultadoEnum.EMPATE));
                }
                pronostics[i - 1] = pronostico;

                var resultadoPartido =partidos[i - 1].resultado(pronostico.getEquipo());
                /// corroboro aqui si la persona acertó o no el partido
                if (pronostico.getResultadoEnum() == resultadoPartido ) {
                    puntos = puntos + pronostico.sumarPuntos();
                }
            }
            System.out.println();
            System.out.println("===========RESULTADO===========");
            System.out.println("Puntos de la ronda -> " + puntos);
            System.out.println("===============================");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    * En esta entrega se debe poder soportar que los archivos contengan información de muchas
      rondas y de muchas personas (para eso hay que agregar los datos de ronda y persona en los
      archivos correspondientes).
      Por otro lado, al leer cada línea del archivo de resultados, se debe verificar que la misma sea
      correcta: número correcto de campos y que la cantidad de goles sea un número entero. Cada
      ronda puede tener cualquier cantidad de partidos.
      Al finalizar el programa, se debe imprimir un listado de los puntajes de cada persona que
      participa.
    *
    *
    * */
    public void segundaEntrega(String[] args) {
        int puntos = 0;

        Path resultados = Paths.get(args[0]);
        Path pronosticos = Paths.get(args[1]);

        try {
            /// esto tiene que tomar del archivo de resultados y contar la cantidad de rondas
            // ¿como lo hace? -> identificando la ronda y cuando sea diferente de la anterior sumar la ronda.

            Ronda ronda = new Ronda();
            Partido[] partidos = new Partido[Files.readAllLines(resultados).size()-1];
            int auxiliarRonda= 1;
            //Comienzo a leer el archivo
            for (int i = 1; i <= partidos.length; i++) {
                // Leo desde la segunda linea [1]
                String line = Files.readAllLines(resultados).get(i);

                System.out.println("===============================");
                System.out.println(line);

                Partido partidito = new Partido();//Se crea el objeto
                partidito.setIdPartido(i);

                String[] dataString = line.split(",");// Split para obtener datos, se en que posiciones está cada dato


                // Guardo la ronda
                if(dataString[0].contains(String.valueOf(auxiliarRonda))){
                    auxiliarRonda=Integer.parseInt(dataString[0]);
                }

                Equipo equipo1 = new Equipo(dataString[1], "Local");
                Equipo equipo2 = new Equipo(dataString[4], "Visitante");

                partidito.setEquipo1(equipo1);
                partidito.setEquipo2(equipo2);

                partidito.setGolesEquipo1(Integer.parseInt(dataString[2]));
                partidito.setGolesEquipo2(Integer.parseInt(dataString[3]));
                System.out.println("===============================");
                System.out.println("Equipo 1 -> " + partidito.resultado(partidito.getEquipo1()));
                System.out.println("Equipo 2 -> " + partidito.resultado(partidito.getEquipo2()));

                //añado el partido al conjunto de partidos
                partidos[i - 1] = partidito;

            }
            System.out.println("================");
            System.out.println("======Ronda=====");
            System.out.println();
            ronda.setPartidos(partidos);
            Pronostico[] pronostics = new Pronostico[2];

            for (int i = 1; i < Files.readAllLines(pronosticos).size(); i++) {
                String line = Files.readAllLines(pronosticos).get(i);
                String[] dataString = line.split(",");
                Pronostico pronostico = new Pronostico();
                pronostico.setPartido(partidos[i - 1]);

                if (dataString[2].toLowerCase().contains("x")) {
                    pronostico.setEquipo(partidos[i - 1].getEquipo1());
                    pronostico.setResultadoEnum((ResultadoEnum.GANADOR));

                } else if (dataString[4].toLowerCase().contains("x")) {
                    pronostico.setEquipo(partidos[i - 1].getEquipo2());
                    pronostico.setResultadoEnum((ResultadoEnum.GANADOR));

                } else {
                    pronostico.setResultadoEnum((ResultadoEnum.EMPATE));
                }
                pronostics[i - 1] = pronostico;

                /// corroboro aqui si la persona acertó o no el partido
                if (pronostico.getResultadoEnum() == partidos[i - 1].resultado(pronostico.getEquipo())) {
                    puntos = pronostico.sumarPuntos();
                }
            }
            System.out.println();
            System.out.println("===========RESULTADO===========");
            System.out.println("Puntos de la ronda -> " + puntos);
            System.out.println("===============================");

        } catch (Exception e) {


        }
    }


}
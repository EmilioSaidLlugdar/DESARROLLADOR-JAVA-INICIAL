package com.argentina.programa.shroot91;

import com.argentina.programa.shroot91.clase1.ClaseUno;
import com.argentina.programa.shroot91.integrador.IntegradorMain;

public class Main {

    public static void main(String[] args) {

     /*   ClaseUno claseUno = new ClaseUno();

        // Ejercicio 1.a
        claseUno.ejercicioA();

        // Ejercicio 1.b
        claseUno.ejercicioB();

        // Ejercicio 1.c
        claseUno.ejercicioC();

        // Ejercicio 1.d
        claseUno.ejercicioD();

        claseUno.ejercicioDos();*/

        IntegradorMain integrador = new IntegradorMain();
        integrador.primeraEntrega(args);
        //integrador.segundaEntrega(args);
    }
}
